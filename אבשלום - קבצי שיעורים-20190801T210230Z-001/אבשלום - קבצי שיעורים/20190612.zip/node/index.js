var http = require('http');
var url = require('url');
var fs = require('fs');
var formidable = require('formidable');


http.createServer(function (req, res) {
    var q = url.parse(req.url, true);
    time_submitted = new Date();

    if (q.pathname == "" || q.pathname == "/") {
        console.log("i am home");
        fs.appendFile('server.log', `${time_submitted} | ${req.connection.remoteAddress} |  ${req.url} | ${q.search}\n`, function (err) {
            if (err) throw err;
            // console.log(`${req.url} | ${time_submitted} | ${q.search}`);
            return res.end();
        });

        var filename = "./templates/index.html";
    } else if (q.pathname == "/submit_form") {

        // var form = new formidable.IncomingForm();
        // form.parse(req, function (err, fields, files) {
        //         console.log(files);
        // });
    


        console.log(q.search); //returns 'february'

        fs.appendFile('server.log', `${time_submitted} | ${req.connection.remoteAddress} |  ${req.url} | ${q.search}\n`, function (err) {
            if (err) throw err;
            // console.log(`${req.url} | ${time_submitted} | ${q.search}`);
            return res.end();
        });
        // return res.end();
        // } else if (req.url == '/css/styles.css') {
        //     console.log("i am styles");

        //     res.setHeader('Content-type', 'text/css');
        //     res.write(fs.readFileSync('css/styles.css'));
        //     return res.end();
    } else {
        var filename = "./templates" + q.pathname + '.html';
    }

    fs.readFile(filename, function (err, data) {
        if (err) {
            res.writeHead(404, { 'Content-Type': 'text/html' });
            return res.end("404 Not Found");
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write(data);
        console.log("home end");
        return res.end();
    });
}).listen(8080);
