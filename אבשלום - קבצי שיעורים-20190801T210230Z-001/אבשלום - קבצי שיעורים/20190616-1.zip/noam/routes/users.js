var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('respond with a resource');
});

//Route for adding cookie 
router.get('/set', (req, res) => {
    //JSON object to be added to cookie 
    let users = [
        {
            name: "Ritisdfk",
            Age: "20"
        },
        {
            name: "Riti sdf sdf sk",
            Age: "18"
        },
        {
            name: "Riti ssds df sdsdgfk",
            Age: "38"
        },
    ]

    res.cookie("userData", users, { expire: 1440 + Date.now(), maxAge: 360000 });
    res.cookie("name", "Noam");
    res.send('user data added to cookie');
});

//Iterate users data from cookie 
router.get('/get', (req, res) => {
    //shows all the cookies 
    res.send(req.cookies);
});

//Iterate users data from cookie 
router.get('/deletename', (req, res) => {
    //shows all the cookies 
    res.clearCookie("name");
    res.send("name deleted");
});


//Iterate users data from cookie 
router.get('/setsession', (req, res) => {
    if(req.session.page_views){
        req.session.page_views++;
        res.send("You visited this page " + req.session.page_views + " times");
     } else {
        req.session.page_views = 1;
        res.send("Welcome to this page for the first time!");
     }
});



module.exports = router;
