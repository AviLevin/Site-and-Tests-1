var mysql = require('mysql')
var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'noam_blog'
})

connection.connect()

module.exports = connection;

