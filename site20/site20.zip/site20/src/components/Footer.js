import React , { Component } from "react";

class Footer extends Component {
  render() {
    return (
      <div>
        <h1>Noam From Footer</h1>
        <p>Noam From Footer</p>
      </div>
    );
  }
}

export default Footer;
