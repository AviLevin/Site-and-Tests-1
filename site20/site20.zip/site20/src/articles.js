const articles = [
    {
        id: 12,
        title: "Noama",
        content: "aaaa noam" 
    },
    {
        id: 294,
        title: "Noamab",
        content: "bbbbaaaa noam" 
    },
    {
        id: 1259,
        title: "Noamcac",
        content: "ccccaaaa noam" 
    },
    {
        id: 4205,
        title: "Noamdad",
        content: "dddddaaaa noam" 
    }
];

export default articles;
