import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

class Post extends Component {
    render() {
        return (
            <div>
                Post
        </div>
        );
    }
}
export default Post;
