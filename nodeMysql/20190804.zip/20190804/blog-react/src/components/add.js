import React from 'react';
import Post from './post/post';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

function Add() {
    return (
        <div> Add </div>
    );
}

export default Add;
